FetchX - APK project

BEFORE YOU START (optional): in capacitor.config.json change
"com.example.fetchx" to something unique, like "com.yourname.fetchx".

EASIEST (no installs, phone or PC):
1. Unzip this file. Make a free GitHub account and a new repository.
2. Upload everything inside the unzipped folder (keep the .github,
   www and assets folders at the top level of the repo).
3. Open the Actions tab > "Build APK" > Run workflow.
4. When it finishes, open the run and download "fetchx-apk".
   Unzip it to get app-debug.apk, then install it on your phone
   (allow "install unknown apps" for your browser or files app).

ON YOUR PC instead (needs Node 18+, JDK 17, Android SDK):
   npm install
   npx cap add android
   npx capacitor-assets generate --android --iconBackgroundColor '#0a0a0a'
   npx cap sync android
   cd android && ./gradlew assembleDebug
   APK: android/app/build/outputs/apk/debug/app-debug.apk

Native HTTP is on (CapacitorHttp), so the app makes requests like a normal
Android app instead of a web page. Servers can still refuse it.

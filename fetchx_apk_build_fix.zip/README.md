# FetchX Android build workflow

This ZIP contains your supplied GitHub Actions APK build workflow at `.github/workflows/build.yml`.

## Use
1. Extract the ZIP into the root of your GitHub repository, preserving the `.github/workflows/build.yml` path.
2. Ensure `fetchx-apk-project-simple-output.zip` exists in the repository root.
3. Commit and push to `main`, or run the workflow manually under GitHub Actions.

Note: This workflow builds an APK; it does not itself change the app's Download button behavior. To fix that, the app source inside the project ZIP needs to be edited.
